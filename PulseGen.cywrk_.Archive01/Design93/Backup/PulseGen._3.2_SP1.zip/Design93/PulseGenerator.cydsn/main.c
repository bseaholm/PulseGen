/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

int main()
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
//    Counter1_Start( );
//    PWM1_Start( );
    Timer1_Start( );

    for(;;)
    {
        /* Place your application code here. */
        
        
        TrigPulseTrain_Write( 1 );                  // Reset counter, trigger another burst
        CyDelayUs( 100 );                           // Delay for 100 uS
    }
}

/* [] END OF FILE */
